The instruction of this program is available here,

https://operanthouse.sakura.ne.jp/profile1025.html