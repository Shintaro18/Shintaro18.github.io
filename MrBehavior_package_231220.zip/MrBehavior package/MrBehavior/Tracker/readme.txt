The instruction of this program is available here,

日本語:
https://operanthouse.sakura.ne.jp/profile1024.html

English:
