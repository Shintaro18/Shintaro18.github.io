Avi recorder ver3.1 (document update: 2020.11.06)

[Usage]
Capturing software

[Requirements]
OS: Windows 7/8.1/10

[How to use]
1) Install Xvid (https://www.xvid.com/download/) for MPEG-4 video coding.
2) If your PC has built-in camera, deactivate it (see below more detail).
3) Connect USB camera.
4) Run AviRecorder.exe
5) Enter camera resolutions into "Camera X resol" and "Camera Y resol" on the left window.
6) Enter output movie size into "Record X size" and "Record Y size".
7) Click "Apply button".
8) Enter "File name", "Frame/sec of out movie" and "Capture duration".
9) Select folder for data output.
10) Click "REC Start" button.

<Deactivation of built-in camera >
Windows 10:
1) Click "Start button" on the task bar.
2) Enter "control panel" then click Control Panel.
3) Select "Large icons" in "View by:" then click "Device Manager".
4) Open "Imaging devices" tree and right click bult-in camera then click "Unable device".


The latest instruction is available here,

https://operanthouse.sakura.ne.jp/profile1022.html