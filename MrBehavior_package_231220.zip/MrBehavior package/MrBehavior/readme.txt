【ソフト名】行動解析君
【ホームページ】https://operanthouse.sakura.ne.jp/profile1.html
【著作権者】大塚信太朗
【連絡先】operanthouse@gmail.com
【圧縮形式】zip
【動作環境】Windows 7/8.1/10
【開発環境】Hot soup processor (https://hsp.tv/)
―――――――――――――――――――――――――――――――――――――
≪著作権および免責事項≫

このソフトは著者が慶應義塾大学医学研究科大学生時代およびNorthwestern大学留学中に、自分自身の研究解析の目的で開発したものです。
コピーレフトソフトウェアですので、どなたでも使用、改変、再配布することができます。
ただし本ソフトウェアを使用した結果を公表する場合は、著者に謝辞をお願いします。
本ソフトウェアを使用したことによる損害、破壊、その他の不都合については、一切責任を負いかねます。

<使い方>
ホームページをご覧ください。
https://operanthouse.sakura.ne.jp/profile1.html

また不具合を見つけた場合、報告して頂けるととても助かります。



================================================================================
[Name] Mr. Behavior
[Web site] https://operanthouse.sakura.ne.jp/profile1.html
[Copyright] Shintaro Otsuka
[email] operanthouse@gmail.com
[OS] Windows 7/8.1/10
[Language] Hot soup processor (https://hsp.tv/)

<Copyright>
This software was developed by the author for the analyses of my own research during his time as a graduate student at Keio University School of Medicine and as a postdoctoral fellow at Northwestern University. 
It is licensed under copyleft and can be utilized, copied, and distributed by anyone, with the condition that proper acknowledgement of the author is provided when publishing results obtained using this software. 
Please note that the author does not assume any responsibility for any damage, destruction, or inconvenience caused by the use of this software.


<How to use>
Please visit the website,
https://operanthouse.sakura.ne.jp/profile1.html

I appreciate any bug reporting to make this software better.